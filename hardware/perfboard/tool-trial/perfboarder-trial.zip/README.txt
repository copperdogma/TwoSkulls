TwoSkulls tool trial - NOT FOR BUILD

A perfboard project. Import it with the app's Import button.
30 x 30 holes, 4 parts, 4 nets.

Exported 2026-10-15T23:38:43.789Z
