TwoSkulls v1 - USB UP - FIT CHECK REQUIRED (2)

A perfboard project. Import it with the app's Import button.
26 x 32 holes, 8 parts, 6 nets.

Exported 2026-10-16T00:02:06.952Z
