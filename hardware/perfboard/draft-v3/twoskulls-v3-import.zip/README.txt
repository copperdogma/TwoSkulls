TwoSkulls v3 design draft. See companion README and assembly drawing. Fit not yet verified.
