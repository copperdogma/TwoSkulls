TwoSkulls v3 - flush USB - underside parts

A perfboard project. Import it with the app's Import button.
26 x 32 holes, 8 parts, 6 nets.

Exported 2026-10-16T06:41:08.293Z
