TwoSkulls v4 - north servo - RF clearance

A perfboard project. Import it with the app's Import button.
26 x 32 holes, 8 parts, 6 nets.

Exported 2026-10-16T14:05:10.884Z
