TwoSkulls v2 - straight rails - review draft

A perfboard project. Import it with the app's Import button.
26 x 32 holes, 8 parts, 6 nets.

Exported 2026-10-16T06:21:18.313Z
